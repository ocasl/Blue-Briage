// 实现选项卡功能
function init() {
  // TODO 待补充代码
}
init();
