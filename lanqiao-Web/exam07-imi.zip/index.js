// 实现选项卡功能
function init() {
  // TODO 待补充代码
  var tab1 = document.getElementsByClassName('red')[0],
  tab2 = document.getElementsByClassName('green')[0],
  tab3 = document.getElementsByClassName('blue')[0],
  tab4 = document.getElementsByClassName('yellow')[0],
  c1 = document.getElementById('one'),
  c2 = document.getElementById('two'),
  c3 = document.getElementById('three');
  c4 = document.getElementById('four');
  function changeTab1() {
    tab1.className = 'red active';
    tab2.className = 'green';
    tab3.className = 'blue';
    tab4.className = 'yellow';
    c1.className = 'active'
    c2.className = '';
    c3.className = '';
    c4.className = '';
  }
  function changeTab2() {
    tab1.className = 'red';
    tab2.className = 'green active';
    tab3.className = 'blue';
    tab4.className = 'yellow';
    c1.className = ''
    c2.className = 'active';
    c3.className = '';
    c4.className = '';
  }
  function changeTab3() {
    tab1.className = 'red';
    tab2.className = 'green';
    tab3.className = 'blue active';
    tab4.className = 'yellow';
    c1.className = ''
    c2.className = '';
    c3.className = 'active';
    c4.className = '';
  }
  function changeTab4() {
    tab1.className = 'red';
    tab2.className = 'green';
    tab3.className = 'blue';
    tab4.className = 'yellow active';
    c1.className = ''
    c2.className = '';
    c3.className = '';
    c4.className = 'active';
  }
  tab1.onclick = changeTab1;
  tab2.onclick = changeTab2;
  tab3.onclick = changeTab3;
  tab4.onclick = changeTab4;
}
init();
