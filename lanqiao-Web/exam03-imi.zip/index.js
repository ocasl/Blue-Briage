$(function () {
    $(".option").on('click', function () {
        $(this).siblings().removeClass('active').find('div').hide();
        $(this).addClass('active');
    });
});